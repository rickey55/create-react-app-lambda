export default function Student(props) {
    return (
        <div>
            <h1>Student Component</h1>
            <button onClick={props.data}>Call Func</button>
        </div>
    )


}